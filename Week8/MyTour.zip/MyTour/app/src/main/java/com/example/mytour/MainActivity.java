package com.example.mytour;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = (Button) findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cal[] = new int[3];
                Calendar c =  getCalendar(0,cal,0);
                DatePickerDialog dp = new DatePickerDialog(MainActivity.this,mylistener, cal[2],cal[0], cal[1]);
                dp.getDatePicker().setMinDate(c.getTimeInMillis());
                dp.show();
            }
        });
    }

    DatePickerDialog.OnDateSetListener mylistener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            int days;
            String destination;
            RadioButton rb = (RadioButton) findViewById(R.id.rb1);
            if (rb.isChecked())
                days = 3 ;
            else
                days = 7;

            int cal[] = {month, dayOfMonth, year};
            RadioGroup rg = ((RadioGroup) findViewById(R.id.rgroup));
            RadioButton r = (RadioButton) findViewById(rg.getCheckedRadioButtonId());
            destination = r.getText().toString();

            Calendar c =  getCalendar(1,cal,days);
            TextView tv = (TextView) findViewById(R.id.txt);
            tv.setText(destination + " [ from " + dayOfMonth + "/" + (month+1) + "/" + year + " to ");
            tv.append(cal[1] + "/" + (cal[0] +1 ) + "/" + cal[2] + " ]");
        }
    };

    private Calendar getCalendar(int flag, int []values,int days) {
        Calendar c = Calendar.getInstance();
        if (flag == 1) {
           c.set(Calendar.MONTH,values[0]);
           c.set(Calendar.DAY_OF_MONTH,values[1]);
           c.set(Calendar.YEAR,values[2]);
           c.add(Calendar.DATE,days-1); // -1 assuming that the current day is included in the counting
        }

        values[0] = c.get(Calendar.MONTH);
        values[1] = c.get(Calendar.DAY_OF_MONTH);
        values[2] = c.get(Calendar.YEAR);
        return c;
    }
}
