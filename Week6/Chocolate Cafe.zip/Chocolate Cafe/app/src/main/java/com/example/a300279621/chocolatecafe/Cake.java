package com.example.a300279621.chocolatecafe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Cake extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cake);
    }
}
