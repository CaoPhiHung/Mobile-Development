package net.androidbootcamp.cityguide;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

public class Willis extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_willis);
    }
}
